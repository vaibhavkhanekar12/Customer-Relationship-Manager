import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomerComponent } from './customer/customer.component';
import { SavecustomerComponent } from './savecustomer/savecustomer.component';
import { UpdatecustomerComponent } from './updatecustomer/updatecustomer.component';

const routes: Routes = [
  {
    path:"",component:CustomerComponent
  },
  {
    path:"Savecustomer",component:SavecustomerComponent
  },
  {
    path:"Updatecustomer",component:UpdatecustomerComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
