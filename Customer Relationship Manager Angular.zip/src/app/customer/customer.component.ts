import { Component, OnInit } from '@angular/core';

import { HttpcustomerService } from '../httpcustomer.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  data:any[]=[];
  customerid !: number;
  firstname !: string;
  lastname !: string;
  emailid !: any;
  router: any;
  isHidden:boolean=false;
  
  constructor(private service : HttpcustomerService) { }

  ngOnInit(): void {
    this.getData();
  }

  getData() {
    this.service.getPost()
    .subscribe((responce:any)=>{
      console.log(responce)
      this.data=responce;
    })
  }
  onEdit(item:any){
    this.customerid =item.customerid;
    this.firstname=item.firstname;
    this.lastname=item.lastname;
    this.emailid=item.emailid;
    console.log(item);

  }
  onDelete(cid:any){
    this.service.DeleteData(cid)
    .subscribe((responce)=>{
      console.log(responce)
    },(myerror:any)=>{
      alert("Employee details deleted....")
      window.location.reload();
    })
    //for reloading page 
  }

  edit(){
    this.isHidden = true;
  }
 
}
