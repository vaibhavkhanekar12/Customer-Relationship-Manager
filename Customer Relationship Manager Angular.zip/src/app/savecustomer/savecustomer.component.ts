import { Component, OnInit } from '@angular/core';
import { HttpcustomerService } from '../httpcustomer.service';

@Component({
  selector: 'app-savecustomer',
  templateUrl: './savecustomer.component.html',
  styleUrls: ['./savecustomer.component.css']
})
export class SavecustomerComponent implements OnInit {

  data:any[]=[];
  customerid !: number;
  firstname !: string;
  lastname !: string;
  emailid !: any;
  router: any;


  constructor(private service : HttpcustomerService) { }

  ngOnInit(): void {
  }

  onSend(cid:any,fname : any,lname : any ,eid : any ){
    let obj ={
      customerid : cid,
      firstname : fname,
      lastname:lname,
      emailid:eid
      
    }
    this.service.PostData(obj)
    .subscribe((response : any)=>{
      console.log(response)
      
    },(msg:any)=>{
      alert("Entery Done successfully..")
      window.location.reload();

    })
    
  }
  
 
}
