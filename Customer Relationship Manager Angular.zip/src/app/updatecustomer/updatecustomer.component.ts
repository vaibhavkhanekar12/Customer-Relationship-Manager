import { Component, OnInit } from '@angular/core';
import { HttpcustomerService } from '../httpcustomer.service';

@Component({
  selector: 'app-updatecustomer',
  templateUrl: './updatecustomer.component.html',
  styleUrls: ['./updatecustomer.component.css']
})
export class UpdatecustomerComponent implements OnInit {

  data:any[]=[];
  customerid !: number;
  firstname !: string;
  lastname !: string;
  emailid !: any;
  router: any;
  isHidden:boolean=false;
  isUpdate:boolean=true;

  constructor(private service : HttpcustomerService) { }

  ngOnInit(): void {
    this.getData();
  }

  getData() {
    this.service.getPost()
    .subscribe((responce:any)=>{
      console.log(responce)
      this.data=responce;
    })
  }
  onEdit(item:any){
    this.customerid =item.customerid;
    this.firstname=item.firstname;
    this.lastname=item.lastname;
    this.emailid=item.emailid;
    this.isUpdate = false;
    this.isHidden = true;
    console.log(item);

  }

  onUpdate(){
  
    let obj ={
      customerid :this.customerid,
      firstname : this.firstname,
      lastname:this.lastname,
      emailid:this.emailid
    }
    this.service.Update(obj)
    .subscribe((response)=>{
      console.log(response)
      this.customerid=0;
      this.firstname='';
      this.lastname='';
      this.emailid='';
    },(msg:any)=>{
      alert("Update Done successfully..")
      window.location.reload();})
  }
}
