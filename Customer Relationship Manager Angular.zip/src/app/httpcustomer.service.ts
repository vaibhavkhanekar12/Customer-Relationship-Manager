import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HttpcustomerService {

  private url : string='http://localhost:9898/customer';

  constructor(private http : HttpClient) { }
  getPost(){
    return (this.http.get(`${this.url}/getcustomer`));
  }

  PostData(obj:any){
    return (this.http.post(`${this.url}/addCustomer`,obj));
  }
  Update(obj:any){
   return (this.http.put(`${this.url}/updatecustomer/${obj.customerid}`,obj))
  }
  DeleteData(cid:any){
       return (this.http.delete(`${this.url}/deletecustomer/${cid}`));
  }
}
