import { TestBed } from '@angular/core/testing';

import { HttpcustomerService } from './httpcustomer.service';

describe('HttpcustomerService', () => {
  let service: HttpcustomerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HttpcustomerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
