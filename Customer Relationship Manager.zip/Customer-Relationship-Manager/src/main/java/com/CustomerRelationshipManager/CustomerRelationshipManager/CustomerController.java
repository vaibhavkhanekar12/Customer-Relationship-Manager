package com.CustomerRelationshipManager.CustomerRelationshipManager;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("customer")
@CrossOrigin("http://localhost:4200/")
public class CustomerController {
	@Autowired
	CustomerService customerService;
	
	@PostMapping("addCustomer")
	public String add_customer_details(@RequestBody Customer customer) {
		
		String msg = customerService.addCustomerService(customer);
		return msg;
	}

	@GetMapping("getcustomer")
	public List<Customer> get_customer_details() {
		
		List<Customer> customer = customerService.getCustomerService();
		return customer;
	}
	@GetMapping("getcustomer/{customerid}") 
	public Customer get_customer_detail(@PathVariable int customerid) {
		
		Customer customer = customerService.getCustomerService(customerid);
		return customer;
	}
	
	@PutMapping("updatecustomer/{customerid}")
	public String update_customer_detail(@RequestBody Customer customer, @PathVariable int customerid) {
		String customerMsg = customerService.updateCustomerService(customer, customerid);
		return customerMsg;
	}
	
	@DeleteMapping("deletecustomer/{customerid}")
	public String delete_customer_detail(@PathVariable int customerid) {
		String customerMsg = customerService.deleteCustomerService(customerid);
		return customerMsg;
	}
	
}
