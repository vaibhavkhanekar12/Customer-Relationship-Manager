package com.CustomerRelationshipManager.CustomerRelationshipManager;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class CustomerService {
	@Autowired
	CustomerDao customerDao;

	public String addCustomerService(Customer customer) {

		String cs = customerDao.postCustomer(customer);

		return cs;
	}

	public List<Customer> getCustomerService() {
		List<Customer> list = customerDao.getCustomer();
		return list;
	}

	public Customer getCustomerService(int customerid) {
		Customer customer = customerDao.getCustomer(customerid);
		return customer;
	}

	public String updateCustomerService(Customer customer, int customerid) {
		String customerMsg = customerDao.updateCustomer(customer, customerid);
		return customerMsg;
	}

	public String deleteCustomerService(int customerid) {
		String customerMsg = customerDao.deleteCustomer(customerid);
		return customerMsg;
	}

}
