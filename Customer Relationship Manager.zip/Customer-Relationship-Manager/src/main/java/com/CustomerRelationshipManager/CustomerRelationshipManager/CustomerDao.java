package com.CustomerRelationshipManager.CustomerRelationshipManager;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class CustomerDao {
	@Autowired
	SessionFactory factory;

	public String postCustomer(Customer customer) {
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+"[a-zA-Z0-9_+&*-]+)*@" +"(?:[a-zA-Z0-9-]+\\.)+[a-z" + "A-Z]{2,7}$";
		
		if(customer.getEmailid().matches(emailRegex)) {
		session.save(customer);
		}else {
			return"Error..";
		}
		transaction.commit();
		return "Record added sussefully";
	}

	public List<Customer> getCustomer() {
		Session session = factory.openSession();
		Query query = session.createQuery("From Customer");
		List<Customer> list = query.list();
		return list;
	}

	public Customer getCustomer(int customerid) {
		Session session = factory.openSession();
		Customer customer = session.load(Customer.class, customerid);
		return customer;
	}

	public String updateCustomer(Customer customer, int customerid) {
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();

		if (customer.getCustomerid() == customerid) {
			session.update(customer);
		}
		transaction.commit();
		return "Successfully Updated";
	}

	public String deleteCustomer(int customerid) {
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		Customer customer = session.load(Customer.class, customerid);
		session.delete(customer);
		transaction.commit();
		return "Successfully Deleted";
	}

}
